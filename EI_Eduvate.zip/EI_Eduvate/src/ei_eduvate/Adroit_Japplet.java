/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ei_eduvate;
import static ei_eduvate.Conc_JApplet.count;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.JPanel;

/**
 *
 * @author lenovo
 */
public class Adroit_Japplet extends javax.swing.JApplet implements Runnable {
    int n=0,test=0;                //test var is for testing if timer has counted 10 secs successfully
 Thread m1=null;
 MediaTracker mt;
 int xcollision=0,ycollision=0;   
    Timer timer;                //to understand the concept of timer see Reminder.java
    int iw,ih;
   int x,y;
   int loop1=0,loop2=0;
  int count1=0;
   static int count=0;
    int limit=0; 
    Image img=null;
    float ans=-1;
    int last;
    int grt=0;                     //for count>3000
    int flag=0;                     
    
    
    ArrayList<Integer> along_x=new ArrayList<Integer>();
    ArrayList<Integer> along_y=new ArrayList<Integer>();
    ArrayList<Integer> visible_x=new ArrayList<Integer>();
    ArrayList<Integer> check1=new ArrayList<Integer>();
    ArrayList<Integer> check2=new ArrayList<Integer>();

    /**
     * Initializes the applet Adroit_Japplet
     */
    @Override
    public void init() {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Adroit_Japplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Adroit_Japplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Adroit_Japplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Adroit_Japplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the applet */
           initComponents();
//        try {
//            java.awt.EventQueue.invokeAndWait(new Runnable() {
//                public void run() {
//                    initComponents();
//                }
//            });
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
        m1=new Thread(this);
        m1.start();
        repaint();

    }@Override
    public void run(){
    while(true){
        int i;
        i=0;
        //System.out.println("run");
        if((n==0))
        {
            if(count<3000)
            {
                
            
            System.out.println("alongxinitail:"+along_x.size());
                System.out.println("for1");
                x=(int)(Math.random()*getSize().width);
                y=(int)(Math.random()*getSize().height);
               
                along_x.add(count%3000,x);
                along_y.add(count%3000,y);
                count++;
               
               Toolkit tk = Toolkit.getDefaultToolkit();
        img = tk.getImage("con2.jpg");
        mt = new MediaTracker(this);
        mt.addImage(img, 1);
        try {
            mt.waitForAll();
        }
        catch(InterruptedException ie) {}
                   
                   // img=getImage(getCodeBase(),"con2.jpg");            
            System.out.println("iw="+iw);
        repaint();
     
        try
        {
        Thread.sleep(7);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
                          }

            
            }
            
        }
            
        }
  }
@Override
  public void stop(){
 m1.stop();
 m1=null;
 
 }


    /**
     * This method is called from within the init() method to initialize the
     * form. WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        checkbox1 = new java.awt.Checkbox();

        getContentPane().setLayout(null);

        jButton1.setText("GO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(20, 100, 47, 23);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(20, 60, 6, 20);

        checkbox1.setLabel("checkbox1");
        checkbox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                checkbox1ItemStateChanged(evt);
            }
        });
        getContentPane().add(checkbox1);
        checkbox1.setBounds(10, 30, 84, 20);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        // TODO add your handling code here:
         flag=1;
        try
    {
      ans=Float.parseFloat(jTextField1.getText());
    }
    catch(NumberFormatException ex)
    {
        System.out.println("number format is incorrect");
    }
    finally{
      System.out.println("ans="+ans);
    }
      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void checkbox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_checkbox1ItemStateChanged
       if(checkbox1.getState())

        {
         int check=0;int r=0;
        System.out.println("along_x"+along_x.size());
         n=1;
         for(int z=0;z<3000;z++)
         {
         visible_x.add(z,1);
         }
         jTextField1.setVisible(true);
          jButton1.setVisible(true);
          last=count%3000-1;
         int hmm=0;
            
   for(int i=last;i>=0;i--)
         {
             loop1++;
      for(int j=last-1;j>=0;j--)
          {
              loop2++;
              if(i>j)
              {
              hmm++;
                 if(visible_x.get(j)!=0)
                {
                    if(along_x.get(j)+iw<=along_x.get(i) || along_x.get(i)+iw<along_x.get(j))
                    {
                        System.out.println("too far...");
                        continue;
                    }
                    if(along_y.get(j)+ih<=along_y.get(i)|| along_y.get(i)+ih<along_y.get(j))
                    {
                        System.out.println(" too far in y axis");
                        continue;
                    
                    }
              if(along_x.get(i)<=along_x.get(j)&&(along_x.get(i)+iw)>=along_x.get(j))
               {
                   System.out.println("x axis");
                   xcollision++;
               }
               if(along_y.get(i)<=along_y.get(j)&&(along_y.get(i)+ih)>=along_y.get(j))
               {
                   System.out.println("y axis");
                   ycollision++;
               }
               if(along_x.get(i)<(along_x.get(j)+iw)&&(along_x.get(i)+iw)>(along_x.get(j)+iw))
               {
                   System.out.println("x+iw");
               xcollision++;
               }
               if(along_y.get(i)<(along_y.get(j)+ih) && (along_y.get(i)+ih)>(along_y.get(j)+ih))
               {
                   System.out.println("y+ih");
               ycollision++;
               }
               
 //for opposite condition
           if(along_x.get(j)<=along_x.get(i)&&(along_x.get(j)+iw)>=along_x.get(i))
               {
                   System.out.println("x axis opposite");
                   xcollision++;
               }
           if(along_y.get(j)<=along_y.get(i)&&(along_y.get(j)+ih)>=along_y.get(i))
               {
                   System.out.println("y axis opposite");
               ycollision++;
               }
           if(along_x.get(j)<(along_x.get(i)+iw)&&(along_x.get(j)+iw)>(along_x.get(i)+iw))
               {
                   System.out.println("x+iw opposite");
               xcollision++;
               }
           if(along_y.get(j)<(along_y.get(i)+ih) && (along_y.get(j)+ih)>(along_y.get(i)+ih))
               {
                   System.out.println("y+ih");
               ycollision++;  
               }
          if(xcollision>0 && ycollision>0)
           {
           r++;
               System.out.println("collision");
           
              visible_x.set(j, 0);
              xcollision=0;ycollision=0;
           }
                
              }
                
            }
              else
                  continue;
          }
         }
         
        
            System.out.println("loop1="+loop1);
            System.out.println("loop2="+loop2);
            System.out.println("hmm="+hmm);
             System.out.println("r="+r);

             
        
          
         callToTimer(7); 
        }
    }
         
public void  callToTimer(int seconds){
    timer=new Timer();
    timer.schedule(new TimerImplement(), seconds*1000);
    
         
         
    }



class TimerImplement extends TimerTask{
//run method is invoked whenever timer is up
    public void run(){
        test=1;
        System.out.println("Time is Up!!");
       System.out.println("in text field");
       
        
        repaint();
    }    

    }//GEN-LAST:event_checkbox1ItemStateChanged

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Checkbox checkbox1;
    private javax.swing.JButton jButton1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
