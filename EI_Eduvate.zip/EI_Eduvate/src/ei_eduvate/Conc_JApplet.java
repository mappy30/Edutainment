/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ei_eduvate;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
    
/**
 *
 * @author lenovo
 */
public class Conc_JApplet extends javax.swing.JApplet implements Runnable{

    /**
     * Initializes the applet Conc_JApplet
     */
    int n=0,test=0;                //test var is for testing if timer has counted 10 secs successfully
 Thread m1=null;
 MediaTracker mt;
 int xcollision=0,ycollision=0;   
    Timer timer;                //to understand the concept of timer see Reminder.java
    int iw,ih;
   int x,y;
   int loop1=0,loop2=0;
  int count1=0;
   static int count=0;
    int limit=0; 
    Image img=null;
   int ans=-1;
    int last;
    int grt=0;                     //for count>3000
    int flag=0;                     
    
    ArrayList<Integer> along_x=new ArrayList<Integer>();
    ArrayList<Integer> along_y=new ArrayList<Integer>();
    ArrayList<Integer> visible_x=new ArrayList<Integer>();
    ArrayList<Integer> check1=new ArrayList<Integer>();
   
    
    
    
    
//    public Conc_JApplet(int pra1){
//    this.n=pra1;
//    }

   

    @Override
    public void init() {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Conc_JApplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Conc_JApplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Conc_JApplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Conc_JApplet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        /* Create and display the applet */
         initComponents();
//        try {
//            java.awt.EventQueue.invokeAndWait(new Runnable() {
//                public void run() {
//                    initComponents();
//                }
//            });
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
        m1=new Thread(this);
        m1.start();
     

 
        
           
        
    }

@Override
    public void run(){
    while(true){
        int i;
        i=0;
        //System.out.println("run");
        if((n==0))
        {
            if(count<3000)                       //draws image only until 3000 images are drawn
            {
                                                     //after taht time out is printed
            
            System.out.println("alongxinitail:"+along_x.size());
                System.out.println("for1");
                x=(int)(Math.random()*getSize().width);
                y=(int)(Math.random()*getSize().height);
               
                along_x.add(x);            // x,y coordinates added to the container-
                                          
                along_y.add(y);            //along_x,  along_y   
                count++;
               
        Toolkit tk = Toolkit.getDefaultToolkit();    //for fetching the image
        img = tk.getImage("con2.jpg");
        mt = new MediaTracker(this);
        mt.addImage(img, 1);
        try {
            mt.waitForAll();
        }
        catch(InterruptedException ie) {}
                   
                   // img=getImage(getCodeBase(),"con2.jpg");            
            System.out.println("iw="+iw);
        repaint();
     
        try
        {
        Thread.sleep(7);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
                          }

            
            }
            
        }
            
        }
  }
@Override
  public void stop(){
 m1.stop();
 m1=null;
 
 }
    /**
     * This method is called from within the init() method to initialize the
     * form. WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        button1 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        checkbox1 = new java.awt.Checkbox();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();

        getContentPane().setLayout(null);

        button1.setFont(new java.awt.Font("Comic Sans MS", 3, 18)); // NOI18N
        button1.setLabel("GO");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1);
        button1.setBounds(50, 100, 42, 34);
        getContentPane().add(textField1);
        textField1.setBounds(30, 70, 80, 20);

        checkbox1.setLabel("STOP");
        checkbox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                checkbox1ItemStateChanged(evt);
            }
        });
        getContentPane().add(checkbox1);
        checkbox1.setBounds(20, 30, 58, 20);
        checkbox1.getAccessibleContext().setAccessibleDescription("");

        jFormattedTextField1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("###"))));
        getContentPane().add(jFormattedTextField1);
        jFormattedTextField1.setBounds(20, 140, 109, 20);
    }// </editor-fold>//GEN-END:initComponents

   
    @Override
    public void update(Graphics g){
        System.out.println("in update");
    repaint();
    }
    
    
   
    @Override
    public void paint(Graphics g)
    {
       // super.paint(g);
         Graphics2D g2 = (Graphics2D) g;
        float thickness = 3;
        Stroke oldStroke = g2.getStroke();
        g2.setStroke(new BasicStroke(thickness));  //increasing thickness of rectangle drawn
      
       Font f=new Font("Cooper Black",Font.BOLD,50);
       g.setColor(Color.RED);
       g.setFont(f);
        if(count>=3000)
         {
      // System.out.println("count>3000");
       g.drawString("Time Out ... Play Again..",150, 150);
        //user didn't tick the check box
         }
       
       if((n==0))             //checkbox is not ticked - images keep on drawing at random x, y coordinates
        {
       
           boolean n= g.drawImage(img, x, y, this);
            System.out.println("draw="+n);
            System.out.println(x+ "    "+y);
            System.out.println("BEFORE"+along_x.size());
            System.out.println("BEFORE"+along_y.size());
    
     
        iw=img.getWidth(this);
        ih=img.getHeight(this);
            System.out.println("Size of arrayList:"+along_x.size());
        
        }      
       else if(test==1)  //test==1 => all calculations being done and time is up..
         {
       
    g.drawString("Time is Up!!!", 150, 150);
        System.out.println("visible.size"+visible_x.size());
        System.out.println("loop1+"+loop1+"lo0p2+"+loop2);
        int o=0;
   
        for(int om=0;om<along_x.size();om++){
               
        if(visible_x.get(om)==1)
        {
            if(along_x.get(om)+iw<=this.getWidth()&& along_y.get(om)+ih<this.getHeight())
            {
            g2.drawRect(along_x.get(om), along_y.get(om), iw, ih);
            o++;   // o counts the no. of images still visible 
                  // visible_x.get( any_index) returns 1  => image is still visible after the calculations
            }
            
            
            
        }
    }
        System.out.println("c="+o);
    if(flag==0){              // user was not able to press the go button so we tell him the corect answer
     g.drawString("Correct answer is : "+o, 150, 250);
    }
    else
    {
    if(ans==o)    //if his answer matches with textbox values print that his answer is correct
        g.drawString("Your answer is correct", 150, 250);

    else if(ans!=o)  //answer is incorrect
    {
     g.drawString("Wrong answer", 150, 250);
     g.drawString("Correct answer is"+o, 150, 350);
    }
    
    }
    }
     
   
       
    } 
  
    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        // TODO add your handling code here:
        
        // this method ensures submission of user's answer from the textfield
          flag=1;
          try
          {
          ans=Integer.parseInt(textField1.getText());
          }
          catch(NumberFormatException e){
           
          }
             System.out.println("ans="+ans);
    }//GEN-LAST:event_button1ActionPerformed

    private void checkbox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_checkbox1ItemStateChanged
        // TODO add your handling code here:
        //this method handles all calculations of rejecting the invisible images 
      
         int check=0;int r=0;
        System.out.println("along_x"+along_x.size());
         n=1;
         for(int z=0;z<3000;z++)
         {
         visible_x.add(z,1);     //all images are said to be visible
         }
         textField1.setVisible(true);
          button1.setVisible(true);
          last=count%3000-1;  //index of last image drawn
         int hmm=0;
            
  for(int i=last;i>=0;i--)
         {
             loop1++;                       
    for(int j=last-1;j>=0;j--)
          {
               loop2++;
        if(i>j)
           {
              hmm++;
         
              if(visible_x.get(j)!=0)
                {
                 if(along_x.get(j)+iw<=along_x.get(i) || along_x.get(i)+iw<along_x.get(j))
                     {
                        System.out.println("too far...");
                        continue;
                     }
                 if(along_y.get(j)+ih<=along_y.get(i)|| along_y.get(i)+ih<along_y.get(j))
                     {
                        System.out.println(" too far in y axis");
                        continue;
                    
                     }
                 if(along_x.get(i)<=along_x.get(j)&&(along_x.get(i)+iw)>=along_x.get(j))
                    {
                       System.out.println("x axis");
                       xcollision++;
                    }
                 if(along_y.get(i)<=along_y.get(j)&&(along_y.get(i)+ih)>=along_y.get(j))
                    {
                       System.out.println("y axis");
                      ycollision++;
                    }
                 if(along_x.get(i)<(along_x.get(j)+iw)&&(along_x.get(i)+iw)>(along_x.get(j)+iw))
                   {
                   System.out.println("x+iw");
                   xcollision++;
                   }
                 if(along_y.get(i)<(along_y.get(j)+ih) && (along_y.get(i)+ih)>(along_y.get(j)+ih))
                   {
                   System.out.println("y+ih");
                   ycollision++;
                   }
               
 //for opposite condition
                if(along_x.get(j)<=along_x.get(i)&&(along_x.get(j)+iw)>=along_x.get(i))
                   {
                   System.out.println("x axis opposite");
                   xcollision++;
                   }
                if(along_y.get(j)<=along_y.get(i)&&(along_y.get(j)+ih)>=along_y.get(i))
                   {
                   System.out.println("y axis opposite");
                   ycollision++;
                   }
               if(along_x.get(j)<(along_x.get(i)+iw)&&(along_x.get(j)+iw)>(along_x.get(i)+iw))
                   {
                   System.out.println("x+iw opposite");
                   xcollision++;
                   }
               if(along_y.get(j)<(along_y.get(i)+ih) && (along_y.get(j)+ih)>(along_y.get(i)+ih))
                   {
                   System.out.println("y+ih");
                   ycollision++;  
                   }
               if(xcollision>0 && ycollision>0)
                  {
                   r++ ;
                   System.out.println("collision");
           
                   visible_x.set(j, 0);
                   xcollision=0;ycollision=0;
                  }
                
              }
                
            }
              else
                  continue;
          }
         }
         
        
            System.out.println("loop1="+loop1);
            System.out.println("loop2="+loop2);
            System.out.println("hmm="+hmm);
            System.out.println("r="+r);

             
        
          
         callToTimer(7); 
        
         

    }//GEN-LAST:event_checkbox1ItemStateChanged

         



    public void  callToTimer(int seconds){
    timer=new Timer();
    timer.schedule(new TimerImplement(), seconds*1000);
    
         
         
    }



class TimerImplement extends TimerTask{
//run method is invoked whenever timer is up
    public void run(){
        test=1;
        System.out.println("Time is Up!!");
       System.out.println("in text field");
       
        
        repaint();
    }    
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    public java.awt.Checkbox checkbox1;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private java.awt.TextField textField1;
    // End of variables declaration//GEN-END:variables
}
